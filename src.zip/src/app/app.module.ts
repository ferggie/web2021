import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FooterComponent } from './common/footer/footer.component';
import { MainNavComponent } from './common/main-nav/main-nav.component';
import { NosotrosComponent } from './home/nosotros/nosotros.component';
import { HistoriaComponent } from './home/historia/historia.component';
import { CarouselComponent } from './common/carousel/carousel.component';
import { InicioComponent } from './home/inicio/inicio.component';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    MainNavComponent,
    NosotrosComponent,
    HistoriaComponent,
    CarouselComponent,
    InicioComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

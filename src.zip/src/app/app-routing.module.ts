import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { InicioComponent } from './home/inicio/inicio.component';
import { HistoriaComponent } from './home/historia/historia.component';

const routes: Routes = [
  {path: '', component: InicioComponent},
  {path: 'historia', component: HistoriaComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
